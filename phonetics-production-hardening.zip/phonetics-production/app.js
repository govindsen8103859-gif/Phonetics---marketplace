(() => {
  "use strict";
  const cfg = window.PHONETICS_CONFIG || {};
  const $ = (s) => document.querySelector(s);
  const grid = $("#phoneGrid");
  let listings = [];
  let activeBrand = "all";
  $("#year").textContent = new Date().getFullYear();

  const nav = $("#mainNav");
  $("#menuToggle").addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    $("#menuToggle").setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

  function msg(el, text, error=false) {
    el.textContent = text;
    el.classList.toggle("error", error);
  }
  function clean(v, max=500) { return String(v ?? "").trim().slice(0,max); }
  function esc(v) {
    return String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function price(v) {
    const n=Number(v);
    return Number.isFinite(n)&&n>0 ? new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n) : "Price on request";
  }
  let client;
  function getClient() {
    if (!window.supabase || !cfg.supabaseUrl || !cfg.supabasePublishableKey) throw new Error("Supabase configuration is missing.");
    if (!client) client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabasePublishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    return client;
  }
  async function callFunction(name, body) {
    const sb=getClient();
    const {data,error}=await sb.functions.invoke(name,{body});
    if(error) {
      let detail=error.message || "Request failed.";
      try { if(error.context && typeof error.context.json==="function"){const d=await error.context.json();detail=d.error||detail;} } catch {}
      throw new Error(detail);
    }
    if(data && data.error) throw new Error(data.error);
    return data;
  }
  function mapListing(r) {
    return {
      id:r.id,
      brand:clean(r.brand||r.phone_brand||"Phone",80),
      model:clean(r.model||r.phone_model||r.title||"Phone listing",120),
      variant:clean(r.variant||r.ram_storage||"",100),
      condition:clean(r.condition||"Pre-owned",60),
      description:clean(r.public_description||r.description||"Ask us for details.",1000),
      price:r.public_price ?? r.selling_price ?? r.price ?? null,
      photo:r.cover_photo_url||r.image_url||""
    };
  }
  function render() {
    const q=clean($("#phoneSearch").value,100).toLowerCase();
    const filtered=listings.filter(p=>(activeBrand==="all"||p.brand.toLowerCase()===activeBrand.toLowerCase())&&`${p.brand} ${p.model} ${p.variant}`.toLowerCase().includes(q));
    if(!filtered.length) {
      grid.innerHTML=`<div class="empty-state"><b>${listings.length?"No matching phones":"No approved phones are available right now."}</b><span>${listings.length?"Try a different search.":"Please check back soon."}</span></div>`;
      return;
    }
    grid.innerHTML=filtered.map(p=>{
      const art=p.photo && /^https:\/\//i.test(p.photo) ? `<img src="${esc(p.photo)}" alt="${esc(p.brand+" "+p.model)}" loading="lazy" onerror="this.remove()">` : `<div class="phone-illustration" aria-hidden="true"></div>`;
      return `<article class="phone-card"><div class="phone-image">${art}<span class="condition-pill">${esc(p.condition)}</span></div><div class="phone-card-body"><div class="phone-brand">${esc(p.brand)}</div><h3>${esc(p.model)}</h3><div class="phone-variant">${esc(p.variant)}</div><div class="phone-meta"><span>Pre-owned</span><span>Reviewed listing</span></div><div class="phone-price-row"><div class="phone-price">${esc(price(p.price))}<small>Public listing price</small></div><button class="small-enquire" data-id="${esc(p.id)}">View / enquire ↗</button></div></div></article>`;
    }).join("");
    grid.querySelectorAll("[data-id]").forEach(b=>b.addEventListener("click",()=>{
      const p=listings.find(x=>String(x.id)===b.dataset.id);
      if(!p)return;
      $("#buyerPhoneInterest").value=`${p.brand} ${p.model}${p.variant?" — "+p.variant:""}`;
      $("#dialogContent").innerHTML=`<div class="eyebrow">PHONETICS LISTING</div><h2 class="dialog-phone-title">${esc(p.brand)} ${esc(p.model)}</h2><div class="dialog-price">${esc(price(p.price))}</div><p class="dialog-details">${esc(p.condition)}${p.variant?" · "+esc(p.variant):""}</p><p class="dialog-details">${esc(p.description)}</p><p class="dialog-details">Seller contact details are private. Send an enquiry to ask about this phone.</p><a class="button button-gold dialog-cta" href="#enquire" id="dialogEnquire">Enquire about this phone →</a>`;
      $("#enquiryDialog").showModal();
      $("#dialogEnquire").addEventListener("click",()=>$("#enquiryDialog").close());
    }));
  }
  $("#closeDialog").addEventListener("click",()=>$("#enquiryDialog").close());
  $("#enquiryDialog").addEventListener("click",e=>{if(e.target===$("#enquiryDialog"))$("#enquiryDialog").close();});
  $("#phoneSearch").addEventListener("input",render);
  document.querySelectorAll(".filter-chip").forEach(b=>b.addEventListener("click",()=>{
    document.querySelectorAll(".filter-chip").forEach(x=>x.classList.remove("active"));
    b.classList.add("active");activeBrand=b.dataset.brand;render();
  }));

  async function loadListings(){
    try {
      const sb=getClient();
      const {data,error}=await sb.from(cfg.publicListingsView).select("*").limit(100);
      if(error)throw error;
      listings=(data||[]).map(mapListing);
      render();
    } catch(e) {
      console.error("Public listing load failed:",e);
      grid.innerHTML=`<div class="empty-state"><b>Listings are temporarily unavailable.</b><span>The public view or Supabase access needs to be configured and verified.</span></div>`;
    }
  }

  function fileData(file) {
    return new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onload=()=>resolve(String(reader.result).split(",")[1]||"");
      reader.onerror=()=>reject(new Error("Could not read "+file.name));
      reader.readAsDataURL(file);
    });
  }
  async function encodeFiles(files) {
    const allowed={"image/jpeg":true,"image/png":true,"image/webp":true,"application/pdf":true};
    const result=[];
    for(const file of files){
      if(!allowed[file.type])throw new Error("Unsupported file type: "+file.name);
      if(file.size>5*1024*1024)throw new Error("Each file must be 5 MB or smaller: "+file.name);
      result.push({name:file.name,type:file.type,size:file.size,base64:await fileData(file)});
    }
    return result;
  }
  $("#sellerForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const form=e.currentTarget, m=$("#sellerMessage"), button=form.querySelector('button[type="submit"]');
    msg(m,"");
    if(!form.reportValidity())return;
    const photos=Array.from($("#sellerPhotos").files||[]);
    const proof=$("#sellerProof").files?.[0];
    if(photos.length<1||photos.length>5){msg(m,"Choose between 1 and 5 phone photos.",true);return;}
    button.disabled=true;button.textContent="Submitting…";
    try{
      const f=new FormData(form);
      const photoFiles=await encodeFiles(photos);
      const proofFiles=proof?await encodeFiles([proof]):[];
      await callFunction(cfg.functions.submitSeller,{
        seller_name:clean(f.get("seller_name"),100),
        seller_email:clean(f.get("seller_email"),254),
        seller_phone:clean(f.get("seller_phone"),20),
        brand:clean(f.get("brand"),80),
        model:clean(f.get("model"),100),
        variant:clean(f.get("variant"),60),
        condition:clean(f.get("condition"),60),
        asking_price:Number(f.get("asking_price")),
        description:clean(f.get("description"),1500),
        photos:photoFiles,
        proof:proofFiles[0]||null,
        consent:f.get("consent")==="on"
      });
      form.reset();msg(m,"Submission received for review. It is not public until approved.");
    }catch(err){console.error(err);msg(m,err.message||"Submission failed. Please try again.",true);}
    finally{button.disabled=false;button.innerHTML='Submit for review <span>→</span>';}
  });
  $("#buyerForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const form=e.currentTarget,m=$("#buyerMessage"),button=form.querySelector('button[type="submit"]');
    msg(m,"");if(!form.reportValidity())return;
    const f=new FormData(form);button.disabled=true;button.textContent="Sending…";
    try{
      await callFunction(cfg.functions.submitBuyer,{
        buyer_name:clean(f.get("buyer_name"),100),
        buyer_email:clean(f.get("buyer_email"),254),
        buyer_phone:clean(f.get("buyer_phone"),20),
        phone_interest:clean(f.get("phone_interest"),200),
        message:clean(f.get("message"),1000)
      });
      form.reset();msg(m,"Your enquiry has been received.");
    }catch(err){console.error(err);msg(m,err.message||"Enquiry could not be sent.",true);}
    finally{button.disabled=false;button.innerHTML='Send enquiry <span>→</span>';}
  });
  loadListings();
})();
