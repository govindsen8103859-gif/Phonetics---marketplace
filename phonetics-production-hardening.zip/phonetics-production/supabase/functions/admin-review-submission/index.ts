import { json, preflight, cleanText, safeJson } from "../_shared/http.ts";
import { requireAdmin } from "../_shared/supabase.ts";
Deno.serve(async (req) => {
  const pre = preflight(req); if (pre) return pre;
  try {
    const { admin, user } = await requireAdmin(req);
    const b = await safeJson(req);
    if (!b || typeof b.id !== "string") return json({ error:"Submission ID is required." },400);
    const decision = b.decision;
    if (!["approved","rejected"].includes(decision)) return json({ error:"Decision must be approved or rejected." },400);
    const note = cleanText(b.admin_note,1000);
    const public_price = decision === "approved" ? Number(b.public_price) : null;
    if (decision === "approved" && (!Number.isInteger(public_price) || public_price < 1 || public_price > 10000000)) return json({ error:"A valid public price is required for approval." },400);
    // Schema contract: update existing submission and corresponding listing using actual column names.
    // This starter deliberately refuses to guess at the phone_listings relationship.
    const { data: submission, error: readError } = await admin.from("seller_submissions")
      .select("id,status,brand,model,variant,condition,description,photo_paths")
      .eq("id",b.id).maybeSingle();
    if (readError) throw new Error("Could not read submission. Verify schema.");
    if (!submission) return json({ error:"Submission not found." },404);
    const { error: updateError } = await admin.from("seller_submissions").update({
      status:decision, admin_note:note, reviewed_by:user.id, reviewed_at:new Date().toISOString()
    }).eq("id",b.id);
    if (updateError) throw new Error("Review status could not be saved. Verify admin review columns.");
    if (decision === "approved") {
      // Do not publish automatically until the owner confirms the real phone_listings schema,
      // photo promotion flow, and public view. This avoids accidentally exposing private fields.
      return json({ ok:true, status:decision, public_price, warning:"Submission marked approved, but publishing is not automated until the listing schema and approved-photo promotion are configured." });
    }
    return json({ ok:true, status:decision });
  } catch (e) {
    const text=e instanceof Error?e.message:"Review failed.";
    const status=text.startsWith("Forbidden")?403:(text.includes("Authentication")?401:500);
    return json({error:text},status);
  }
});
