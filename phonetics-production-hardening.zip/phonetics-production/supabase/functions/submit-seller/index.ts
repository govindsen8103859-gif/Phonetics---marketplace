import { corsHeaders, json, preflight, cleanText, validEmail, safeJson, safeFilename } from "../_shared/http.ts";
import { serviceClient } from "../_shared/supabase.ts";

const MAX_FILE = 5 * 1024 * 1024;
const PHOTO_BUCKET = "seller-proofs"; // Private holding area until admin approval.
const PROOF_BUCKET = "seller-proofs";
const MIME = new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"]);

function decodeFile(file: any, imageOnly = false) {
  if (!file || typeof file !== "object" || typeof file.base64 !== "string") throw new Error("Invalid uploaded file.");
  const type = String(file.type || "");
  if (!MIME.has(type) || (imageOnly && type === "application/pdf")) throw new Error("Unsupported file type.");
  const binary = atob(file.base64);
  if (binary.length < 1 || binary.length > MAX_FILE) throw new Error("File must be 5 MB or smaller.");
  const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
  return { bytes, type, name: safeFilename(String(file.name || "")) };
}
Deno.serve(async (req) => {
  const pre = preflight(req); if (pre) return pre;
  try {
    const body = await safeJson(req);
    if (!body || body.consent !== true) return json({ error: "Please confirm the submission consent." }, 400);
    const seller_name = cleanText(body.seller_name, 100);
    const seller_email = cleanText(body.seller_email, 254);
    const seller_phone = cleanText(body.seller_phone, 20);
    const brand = cleanText(body.brand, 80);
    const model = cleanText(body.model, 100);
    const variant = cleanText(body.variant, 60);
    const condition = cleanText(body.condition, 60);
    const description = cleanText(body.description, 1500);
    const asking_price = Number(body.asking_price);
    const photos = Array.isArray(body.photos) ? body.photos : [];
    if (!seller_name || !validEmail(seller_email) || !seller_phone || !brand || !model || !condition || !description) return json({ error: "Please fill all required fields with valid values." }, 400);
    if (!Number.isInteger(asking_price) || asking_price < 1 || asking_price > 10000000) return json({ error: "Enter a valid expected price." }, 400);
    if (photos.length < 1 || photos.length > 5) return json({ error: "Upload 1 to 5 phone photos." }, 400);
    const photoFiles = photos.map((f: any) => decodeFile(f, true));
    const proof = body.proof ? decodeFile(body.proof, false) : null;
    const sb = serviceClient();
    const submissionId = crypto.randomUUID();
    const paths: string[] = [];
    for (const f of photoFiles) {
      const path = `seller-submissions/${submissionId}/photos/${f.name}`;
      const { error } = await sb.storage.from(PHOTO_BUCKET).upload(path, f.bytes, { contentType: f.type, upsert: false });
      if (error) throw new Error("Could not securely store phone photos. Please try again.");
      paths.push(path);
    }
    let proof_path: string | null = null;
    if (proof) {
      proof_path = `seller-submissions/${submissionId}/proof/${proof.name}`;
      const { error } = await sb.storage.from(PROOF_BUCKET).upload(proof_path, proof.bytes, { contentType: proof.type, upsert: false });
      if (error) throw new Error("Could not securely store the supporting file.");
    }
    // SCHEMA CONTRACT: align these field names with the already-existing table after inspection.
    const row = {
      id: submissionId, seller_name, seller_email, seller_phone, brand, model, variant,
      condition, asking_price, description, photo_paths: paths, proof_path,
      status: "pending", created_at: new Date().toISOString()
    };
    const { error: insertError } = await sb.from("seller_submissions").insert(row);
    if (insertError) {
      // Best-effort cleanup to avoid orphaned uploads.
      await sb.storage.from(PHOTO_BUCKET).remove(paths);
      if (proof_path) await sb.storage.from(PROOF_BUCKET).remove([proof_path]);
      console.error("Seller submission insert failed:", insertError.message);
      return json({ error: "Submission could not be saved. Please contact support." }, 500);
    }
    return json({ ok: true, submission_id: submissionId }, 201);
  } catch (e) {
    console.error("submit-seller failed:", e instanceof Error ? e.message : "unknown error");
    return json({ error: e instanceof Error ? e.message : "Submission failed." }, 400);
  }
});
