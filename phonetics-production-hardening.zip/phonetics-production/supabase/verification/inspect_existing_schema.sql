/*
  READ-ONLY INSPECTION.
  Run this first in Supabase SQL Editor. It reads schema metadata only;
  it does not read customer rows or alter database objects.
*/
WITH target_tables AS (
    SELECT unnest(ARRAY[
        'admin_users',
        'seller_submissions',
        'phone_listings',
        'buyer_requests'
    ]) AS table_name
),
table_details AS (
    SELECT
        t.table_name,
        (
            SELECT jsonb_agg(
                jsonb_build_object(
                    'column', c.column_name,
                    'type', c.data_type,
                    'nullable', c.is_nullable,
                    'default', c.column_default
                )
                ORDER BY c.ordinal_position
            )
            FROM information_schema.columns c
            WHERE c.table_schema = 'public'
              AND c.table_name = t.table_name
        ) AS columns,
        (
            SELECT jsonb_agg(
                jsonb_build_object(
                    'constraint', tc.constraint_name,
                    'type', tc.constraint_type,
                    'definition', pg_get_constraintdef(pc.oid)
                )
            )
            FROM information_schema.table_constraints tc
            JOIN pg_constraint pc
              ON pc.conname = tc.constraint_name
             AND pc.conrelid =
                 (quote_ident('public') || '.' ||
                  quote_ident(t.table_name))::regclass
            WHERE tc.table_schema = 'public'
              AND tc.table_name = t.table_name
        ) AS constraints,
        (
            SELECT jsonb_build_object(
                'rls_enabled', p.rowsecurity,
                'force_rls', p.forcerowsecurity
            )
            FROM pg_class p
            JOIN pg_namespace n ON n.oid = p.relnamespace
            WHERE n.nspname = 'public'
              AND p.relname = t.table_name
        ) AS security
    FROM target_tables t
),
policies AS (
    SELECT jsonb_agg(
        jsonb_build_object(
            'table', tablename,
            'name', policyname,
            'command', cmd,
            'roles', roles,
            'using', qual,
            'check', with_check
        )
        ORDER BY tablename, policyname
    ) AS data
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN (
          'admin_users',
          'seller_submissions',
          'phone_listings',
          'buyer_requests'
      )
),
storage_buckets AS (
    SELECT jsonb_agg(
        jsonb_build_object(
            'name', id,
            'public', public,
            'file_size_limit', file_size_limit,
            'allowed_mime_types', allowed_mime_types
        )
        ORDER BY id
    ) AS data
    FROM storage.buckets
    WHERE id IN ('seller-proofs', 'phone-photos')
),
storage_policies AS (
    SELECT jsonb_agg(
        jsonb_build_object(
            'name', policyname,
            'command', cmd,
            'roles', roles,
            'using', qual,
            'check', with_check
        )
        ORDER BY policyname
    ) AS data
    FROM pg_policies
    WHERE schemaname = 'storage'
      AND tablename = 'objects'
)
SELECT jsonb_pretty(
    jsonb_build_object(
        'tables', (
            SELECT jsonb_agg(to_jsonb(td) ORDER BY td.table_name)
            FROM table_details td
        ),
        'policies', (SELECT data FROM policies),
        'storage_buckets', (SELECT data FROM storage_buckets),
        'storage_policies', (SELECT data FROM storage_policies)
    )
) AS inspection_report;
