(() => {
"use strict";
const cfg=window.PHONETICS_CONFIG||{};
const $=s=>document.querySelector(s);
let sb;
function client(){if(!window.supabase)throw new Error("Supabase SDK failed to load.");if(!sb)sb=window.supabase.createClient(cfg.supabaseUrl,cfg.supabasePublishableKey,{auth:{persistSession:true,autoRefreshToken:true}});return sb;}
function status(el,text,error=true){el.textContent=text;el.style.color=error?"#9c2525":"#267d5d";}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function fn(name,body){const {data,error}=await client().functions.invoke(name,{body});if(error)throw new Error(error.message||"Request failed");if(data?.error)throw new Error(data.error);return data;}
async function showSession(){
 const {data}=await client().auth.getSession();
 if(data.session){$("#loginPanel").classList.add("hidden");$("#dashboardPanel").classList.remove("hidden");await load();}
 else{$("#loginPanel").classList.remove("hidden");$("#dashboardPanel").classList.add("hidden");}
}
async function load(){
 status($("#dashboardMessage"),"Loading submissions…",false);
 try{
  const data=await fn(cfg.functions.adminListSubmissions,{});
  const rows=data.submissions||[];
  $("#submissions").innerHTML=rows.length?rows.map(r=>`<article class="admin-item" data-id="${esc(r.id)}"><h3>${esc(r.brand)} ${esc(r.model)}</h3><div class="admin-meta">Seller: ${esc(r.seller_name)}\nEmail: ${esc(r.seller_email)}\nPhone: ${esc(r.seller_phone)}\nCondition: ${esc(r.condition)} · Variant: ${esc(r.variant)}\nExpected price: ₹${esc(r.asking_price)}\nDescription: ${esc(r.description)}\nProof path: ${esc(r.proof_path||"None")}\nPhoto paths: ${esc((r.photo_paths||[]).join(", "))}</div><label style="display:block;margin-top:12px;font-size:12px">Admin note<textarea class="admin-note" rows="2" maxlength="1000" style="display:block;width:100%;margin-top:6px"></textarea></label><label style="display:block;margin-top:10px;font-size:12px">Public price for approval (₹)<input class="public-price" type="number" min="1" max="10000000" step="1" style="display:block;width:100%;margin-top:6px;padding:10px;border:1px solid #dfe4ec;border-radius:8px"></label><div class="admin-actions"><button class="approve" data-decision="approved">Approve review</button><button class="reject" data-decision="rejected">Reject</button></div><p class="admin-status item-status" role="status"></p></article>`).join(""):`<div class="empty-state"><b>No pending submissions</b><span>New submissions will appear here when the backend is configured.</span></div>`;
  $("#submissions").querySelectorAll("[data-decision]").forEach(b=>b.addEventListener("click",async()=>{
   const item=b.closest(".admin-item"), id=item.dataset.id, decision=b.dataset.decision, note=item.querySelector(".admin-note").value, public_price=Number(item.querySelector(".public-price").value);
   const st=item.querySelector(".item-status");
   if(decision==="approved"&&(!Number.isInteger(public_price)||public_price<1)){status(st,"Enter a valid public price before approving.");return;}
   b.disabled=true;
   try{
    const result=await fn(cfg.functions.adminReviewSubmission,{id,decision,admin_note:note,public_price});
    status(st,result.warning||`Submission marked ${decision}.`,false);
    if(result.warning) st.textContent += " Publishing still requires the verified listing workflow.";
    await load();
   }catch(e){status(st,e.message||"Review action failed.");}
   finally{b.disabled=false;}
  }));
  status($("#dashboardMessage"),`Loaded ${rows.length} pending submission(s).`,false);
 }catch(e){$("#submissions").innerHTML="";status($("#dashboardMessage"),e.message||"Could not load submissions.");}
}
$("#loginForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.currentTarget);
 try{const {error}=await client().auth.signInWithPassword({email:f.get("email"),password:f.get("password")});if(error)throw error;status($("#loginMessage"),"Signed in.",false);await showSession();}
 catch(err){status($("#loginMessage"),"Sign-in failed. Check your account and Supabase Auth settings.");}
});
$("#logout").addEventListener("click",async()=>{await client().auth.signOut();await showSession();});
$("#refresh").addEventListener("click",load);
showSession().catch(e=>status($("#loginMessage"),e.message));
})();
