/*
 * Browser-safe configuration only.
 * Never place SUPABASE_SERVICE_ROLE_KEY or any secret in this file.
 */
window.PHONETICS_CONFIG = {
  supabaseUrl: "https://vuvznvwlzlabfaasylss.supabase.co",
  supabasePublishableKey: "sb_publishable_E885kuUfeqieX5c0l0zgMQ_DBI76YAY",
  functions: {
    submitSeller: "submit-seller",
    submitBuyer: "submit-buyer",
    adminListSubmissions: "admin-list-submissions",
    adminReviewSubmission: "admin-review-submission"
  },
  publicListingsView: "public_phone_listings",
  storage: {
    // New, unreviewed seller images and proofs must stay in private storage.
    privateUploads: "seller-proofs",
    publicApprovedPhotos: "phone-photos"
  }
};
